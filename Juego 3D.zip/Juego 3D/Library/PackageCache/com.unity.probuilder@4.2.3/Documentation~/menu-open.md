# ProBuilder Window

This opens the [ProBuilder toolbar](toolbar.md) and [Edit mode toolbar](edit-mode-toolbar.md) together. 

![ProBuilder toolbar and Edit mode toolbar opens and closes at the same time](images/menu-open.png)

By default, the Edit mode toolbar appears in the upper center of your Unity workspace, and the ProBuilder toolbar appears on the left side. See [Customizing ProBuilder](customizing.md) for information on how to customize the location and appearance of these toolbars and other ProBuilder windows.